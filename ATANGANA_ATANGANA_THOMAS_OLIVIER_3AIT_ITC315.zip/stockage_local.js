function initialize() { /*code à ajouter par la suite */ 



    var bSupportsLocal = (('localStorage' in window) && window['localStorage'] !== null);
    // 1-Quel est le rôle de cette ligne?
	//Elle permet de faire le test du navigateur : supporte t-il le stockage local ? :la variable booléene récupère le résultat. 



    if (!bSupportsLocal) {
        document.getElementById('infoform').innerHTML = "<p>Désolé, ce navigateur ne supporte pas l’API Web Storage du W3C.</p>";
        return;
        } // 2-Qu'est-ce qu'elles permettent de faire ? 
		 //En fonction du résultat et en l'occurence lorsqu'il est faux, l'affichage du message d'erreur s'effectuera dans le sélecteur. 

  
        if (window.localStorage.length != 0) {
    document.getElementById('firstName').value = window.localStorage.getItem('firstName');
    document.getElementById('lastName').value = window.localStorage.getItem('lastName');
    document.getElementById('postCode').value = window.localStorage.getItem('postCode');

    // 3-Décrivez ce qu'elles permettent de faire.
	//Ce code permet de charger le contenu du stockage local si il n'est pas vide.
    }

    function storeLocalContent(fName, lName, pCode) {
        window.localStorage.setItem('firstName', fName);
        window.localStorage.setItem('lastName', lName);
        window.localStorage.setItem('postCode', pCode);
        // C'est une fonction qui permet de résumer le stockage.
        // Elle est appelée quand il faut initialiser les variables de sauvegarde.
        }
//Ecrivez le corps de la fonction permettant de nettoyer le stockage local:
   function clearLocalContent()
   {
       window.localStorage=null;
   }     


}
window.onload = initialize; // chargement du code "initialize" au demarrage de la page